// const lib = require('./lib.js');
// // console.log(lib);

// var e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// var Employee = require('./lib.js').Employee;
// var { Employee } = require('./lib.js');
// var e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const abc = require('./abc.js');
// const lib1 = require('./lib.js');
// const lib2 = require('./lib.js');
// console.log(lib1 === lib2);

// const logger1 = require('./logger1.js');
// const logger = require('./logger');

// const loggerFactory = require('./loggerFactory');

// var dbLogger = loggerFactory.DBLFactory.getLogger();
// var flLogger = loggerFactory.FLFactory.getLogger();

const { DBLFactory, FLFactory } = require('./loggerFactory');
var dbLogger = DBLFactory.getLogger();
var flLogger = FLFactory.getLogger();

dbLogger.log("Hello");
flLogger.log("Hello");