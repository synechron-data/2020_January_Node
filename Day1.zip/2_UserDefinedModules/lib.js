// console.log("Lib Module Loaded.....");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

var fname = "Manish";
var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// exports.firstname = fname;

// module.exports = function () {
//     console.log("Exported Fn");
// }

// exports.log = function () {
//     console.log("Exported Fn");
// }

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}

exports.Employee = Employee;

console.log("Lib Module loaded...");