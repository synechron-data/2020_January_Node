// const readline = require('readline');

// const repl = require('repl');
// let modules = repl._builtinLibs;
// console.log(modules);

const readline = require('readline');
// console.log(readline);

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// rl.question("Enter a number", (n1) => {
//     console.log("Your entered", n1);
//     rl.close();
// });

// rl.question("Enter a number: ", (n1) => {
//     rl.question("Enter a number: ", (n2) => {
//         var sum = parseInt(n1) + parseInt(n2);
//         console.log("Result is: ", sum);
//         rl.close();
//     });
// });

// console.log("Last Line");

function enterNumberOne() {
    return new Promise((resolve) => {
        rl.question("Enter a number: ", (inp) => {
            var num = parseInt(inp);
            resolve(num);
        });
    });
}

function enterNumberTwo(n1) {
    return new Promise((resolve) => {
        rl.question("Enter a number: ", (inp) => {
            var num = parseInt(inp);
            resolve([n1, num]);
        });
    });
}

function add([n1, n2]) {
    var sum = n1 + n2;
    console.log("Result is: ", sum);
    rl.close();
}

enterNumberOne().then(enterNumberTwo).then(add);