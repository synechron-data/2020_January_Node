const StringEmitter = require('./StringEmitter');

var sEmitter = new StringEmitter();

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// sEmitter.pushString((s) => {
//     console.log(s);
// });

sEmitter.on('data', (s) => {
    console.log("S1 - ", s);
});

var cnt = 0;
function S2(s) {
    ++cnt;
    console.log("S2 - ", s);
    if (cnt > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2);