// const fs = require('fs');

// var readStream = fs.createReadStream('./file.txt');
// var writeStream = fs.createWriteStream('./file-copy.txt');

// readStream.pipe(writeStream);
// console.log("File Copied....");

const fs = require('fs');
const zlib = require('zlib');

fs.createReadStream('./file.txt')
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream('./file.txt.gz'));

console.log("File Compressed....");
