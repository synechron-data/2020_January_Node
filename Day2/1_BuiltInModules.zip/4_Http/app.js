// const http = require('http');

// const server = http.createServer((req, res) => {
//     console.log(req.url);
//     res.write("Nothing to Give, from Node HTTP Server");
//     res.end();
// });

// server.listen(3000, () => {
//     console.log("Server Started....");
// });

const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    fs.readFile('./index.html', (err, content) => {
        if (err) throw err;

        // res.setHeader("content-type", "text/html");
        res.setHeader("content-type", "application/pdf");
        res.write(content);
        res.end();
    });
});

server.listen(3000, () => {
    console.log("Server Started....");
});