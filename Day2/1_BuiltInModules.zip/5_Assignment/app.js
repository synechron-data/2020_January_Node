const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    if (req.url != '/favicon.ico') {
        var filepath = `${__dirname}${req.url}.pdf`;


        res.setHeader("content-type", "application/pdf");
        var readStream = fs.createReadStream(filepath);

        readStream.pipe(res);

        // readStream.on('data', (chunk) => {
        //     res.write(chunk);
        // });

        // readStream.on('end', () => {
        //     res.end();
        // });

        readStream.on('error', (err) => {
            res.setHeader("content-type", "text");
            res.end("Error Reading File....");
        });
    }
});

server.listen(3000, () => {
    console.log("Server Started....");
});