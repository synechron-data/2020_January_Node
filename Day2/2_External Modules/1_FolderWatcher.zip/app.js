const chokidar = require('chokidar');

var watcher = chokidar.watch('./Test');

watcher.on('add', (path) => { console.log(`File, ${path}, has been created.`); });
watcher.on('change', (path) => { console.log(`File, ${path}, has been modified.`); });
watcher.on('unlink', (path) => { console.log(`File, ${path}, has been deleted.`); });

console.log("Chokidar Started...");