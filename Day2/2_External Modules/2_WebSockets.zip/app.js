const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    fs.readFile('./index.html', (err, content) => {
        if (err) throw err;

        res.setHeader("content-type", "text/html");
        res.write(content);
        res.end();
    });
});

server.listen(3000, () => {
    console.log("Server Started....");
});

const StringEmitter = require('./StringEmitter');
const sm = new StringEmitter();

sm.on('data', (s) => {
    if (clients.length > 0) {
        for (const c of clients) {
            if (c) {
                c.sendUTF(s);
            }
        }
    }
});

const WebSocketServer = require('websocket').server;

const wsServer = new WebSocketServer({
    httpServer: server
});

var count = 0;
var clients = [];

wsServer.on('request', (req) => {
    var connection = req.accept('echo-protocol');

    var id = count++;
    clients[id] = connection;
    console.log(`Connection Accepted [${id}]`);

    connection.on('close', function () {
        delete clients[id];
        console.log(`Connection Closed [${id}]`);
    });
});