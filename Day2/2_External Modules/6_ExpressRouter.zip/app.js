const express = require('express');
const logger = require('morgan');
const app = express();

const indexRouter = require('./routes/index');

app.set("view engine", "pug");

app.use(logger('dev'));
app.use('/', indexRouter);

module.exports = app;