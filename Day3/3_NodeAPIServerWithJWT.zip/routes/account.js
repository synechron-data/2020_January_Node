var express = require('express');
var router = express.Router();

const accCtrl = require('../controllers/account-controller');

module.exports = function (passport) {
    router.get('/', function (req, res, next) {
        res.redirect('account/login');
    });

    router.get('/login', accCtrl.login_get);

    router.post('/login', accCtrl.login_post(passport));

    router.post('/getToken', accCtrl.requestToken);

    return router;
};
