const da = require('../data-access');

exports.getUsers = function (req, res, next) {
    da.getAllUsers().then((result) => {
        res.json({ data: result, message: "Success, getting Users" });
    }, (err) => {
        res.json({ data: [], message: "Error, getting Users" });
    });
}